<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['intro']	=	'Start';
$lang['step1']	=	'Schritt #1';
$lang['step2']	=	'Schritt #2';
$lang['step3']	=	'Schritt #3';
$lang['step4']	=	'Schritt #4';
$lang['final']	=	'Letzer Schritt';

$lang['installer.passwords_match']		= "Das Passwort stimmt &uuml;berein.";
$lang['installer.passwords_dont_match']	= "Das Passwort stimmt nicht &uuml;berein.";