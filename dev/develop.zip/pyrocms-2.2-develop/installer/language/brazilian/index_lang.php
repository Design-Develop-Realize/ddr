<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['header']		= 'Seja bem-vindo(a)!';
$lang['thankyou']	= 'Obrigado por escolher o PyroCMS.';
$lang['text']		= 'O processo de instalação do PyroCMS é muito simples, apenas siga as instruções de cada etapa.<br>Caso você tenha receio ou alguma dificuldade para fazer a instalação, não se preocupe, o sistema de instalação irá orientá-lo a fazer as escolhas mais apropriadas.';
$lang['step1'] 		= '1ª Etapa';
$lang['link']		= 'Ir para a primeira etapa da instalação';
