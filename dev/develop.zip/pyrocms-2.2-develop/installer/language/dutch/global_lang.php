<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['intro']	=	'Introductie';
$lang['step1']	=	'Stap #1';
$lang['step2']	=	'Stap #2';
$lang['step3']	=	'Stap #3';
$lang['step4']	=	'Stap #4';
$lang['final']	=	'Laatste Stap';

$lang['installer.passwords_match']		= "Wachtwoorden komen overeen.";
$lang['installer.passwords_dont_match']	= "Wachtwoorden komen niet overeen.";