<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['intro']	=	'Wprowadzenie';
$lang['step1']	=	'Krok 1';
$lang['step2']	=	'Krok 2';
$lang['step3']	=	'Krok 3';
$lang['step4']	=	'Krok 4';
$lang['final']	=	'Zakończenie';

$lang['installer.passwords_match']		= "Hasła są jednakowe.";
$lang['installer.passwords_dont_match']	= "Hasła nie są jednakowe.";