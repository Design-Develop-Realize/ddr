<?php defined('BASEPATH') or exit('No direct script access allowed');

// labels
$lang['congrats']			= 'Поздравляем';
$lang['intro_text']			= 'PyroCMS установлена и готова к работе! Данные для доступа в панель администратора:';
$lang['email']				= 'E-mail';
$lang['password']			= 'Пароль';
$lang['show_password']		= 'Show Password?'; #translate
$lang['outro_text']			= 'Последний шаг, <strong>удалите папку установщика с вашего сервера</strong>! Если вы её оставите - она может быть использована для взлома вашего сайта.';

$lang['go_website']			= 'Перейти к сайту';
$lang['go_control_panel']	= 'Перейти в раздел администратора';