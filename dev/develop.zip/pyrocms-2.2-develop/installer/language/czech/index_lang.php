<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['header']		=	'Vítejte';
$lang['thankyou']	= 	'Díky za volbu PyroCMS!';
$lang['text']		=	'Instalace PyroCMS je velmi jednoduchá, jen následujte kroky a pokračujte podle zpráv na obrazovce. Pokud budete mít nějaké problémy s instalací, instalátor vám vše vysvětlí.';
$lang['step1'] 		= 'Krok 1';
$lang['link']		= 'Pokračovat k prvnímu kroku';