<?php defined('BASEPATH') or exit('No direct script access allowed');

// labels
$lang['congrats']            = 'Gratulálunk';
$lang['intro_text']          = 'A PyroCMS telepítve van és használatra kész! Jelentkezz be a Vezérlőpultra az alábbi részletek segítségével.';
$lang['email']               = 'E-mail';
$lang['password']            = 'Jelszó';
$lang['show_password']       = 'Jelszó megjelenítése';
$lang['outro_text']          = 'Végül <strong>töröld a telepítőt - az [installer] könyvtárat - a szerverről, </strong>ugyanis biztonsági rés a jelenléte, amin keresztül feltörhető az oldal.';

$lang['go_website']          = 'Weboldal';
$lang['go_control_panel']    = 'Vezérlőpult';
