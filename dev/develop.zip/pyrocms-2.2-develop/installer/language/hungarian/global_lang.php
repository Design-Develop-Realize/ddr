<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['intro']                   = 'Bevezetés';
$lang['step1']                   = 'Első lépés';
$lang['step2']                   = 'Második lépés';
$lang['step3']                   = 'Harmadik lépés';
$lang['step4']                   = 'Negyedik lépés';
$lang['final']                   = 'Utolsó lépés';

$lang['installer.passwords_match']          = "A jelszavak, egyeznek.";
$lang['installer.passwords_dont_match']     = "A jelszavak, NEM egyeznek.";