<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['header']		=	'Velkommen';
$lang['thankyou']	= 	'Tak fordi du valgte PyroCMS!';
$lang['text']		=	'Det er meget nemt at installere PyroCMS, følg blot trinene og meddelelserne på skærmen. Bliv ikke bekymret i tilfælde af at du har problemer med at installere system, guiden vil forklare hvad du skal gøre.';
$lang['step1'] 		= 'Trin 1';
$lang['link']		= 'Fortsæt til første trin';