<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['header']		=	'Welcome';
$lang['thankyou']	= 	'Thank you for choosing PyroCMS!';
$lang['text']		=	'Installing PyroCMS is very easy, just follow the steps and messages on the screen. In case you have any problems installing the system don\'t worry, the installer will explain what you need to do.';
$lang['step1'] 		= 'Step 1';
$lang['link']		= 'Proceed to the first step';