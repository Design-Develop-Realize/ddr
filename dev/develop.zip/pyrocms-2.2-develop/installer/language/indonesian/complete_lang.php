<?php defined('BASEPATH') or exit('No direct script access allowed');

// labels
$lang['congrats']			= 'Selamat';
$lang['intro_text']			= 'PyroCMS sekarang telah terinstal dan siap digunakan! Silakan masuk ke panel admin dengan menggunakan detail berikut.';
$lang['email']				= 'E-mail';
$lang['password']			= 'Password';
$lang['show_password']		= 'Tampilkan Password?';
$lang['outro_text']			= 'Terakhir, <strong>hapus installer dari server</strong> karena jika Anda meninggalkannya di sana itu akan dapat digunakan untuk meretas situs Anda.';

$lang['go_website']			= 'Buka Situs Web';
$lang['go_control_panel']	= 'Buka Control Panel';