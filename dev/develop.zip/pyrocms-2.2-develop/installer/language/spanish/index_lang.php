<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['header']   = 'Bienvenido';
$lang['thankyou'] = 'Gracias por escoger PyroCMS!';
$lang['text']     = 'Instalar PyroCMS es muy fácil, solo siga los pasos en pantalla. En caso de tener algún problema instalando el sistema no se preocupe, el instalador le explicará que necesita hacer.';
$lang['step1']    = 'Paso 1';
$lang['link']     = 'Proceder al primer paso';
