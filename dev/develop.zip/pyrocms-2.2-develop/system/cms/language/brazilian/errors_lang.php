<?php

// Error 404
$lang['error_404_title'] = 'Página não encontrada';
$lang['error_404_message'] = 'Não conseguimos encontrar a página que você está procurando, por favor, clique <a href="%s">aqui</a> para retornar à página inicial.';

// Database
$lang['error_invalid_db_group'] = 'O banco de dados está tentando utilizar um grupo de configurações inválido: "%s".';

/* End of file errors_lang.php */