<?php defined('BASEPATH') or exit('No direct script access allowed');

 /**
 * Swedish translation.
 *
 * @author		marcus@incore.se
 * @package		PyroCMS
 * @link		http://pyrocms.com
 * @date		2012-10-22
 * @version		1.1.0
 */

$lang['alpha_dot_dash'] = 'Fältet %s får endast innehålla alfanumeriska tecken, understreck, snedstreck och punkter.';
$lang['decimal'] = 'Fältet %s måste innehålla ett decimaltal.';
$lang['csrf_bad_token'] = 'Ogiltig CSRF token';

/* End of file extra_validation_lang.php */