<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= "Polje %s lahko vsebuje samo črke, številke, podčrtaj, piko in vejico.";
$lang['decimal']				= "Polje %s vsebuje lahko decimalno številko.";
$lang['csrf_bad_token']			= "Neveljaven CSRF Token";

/* End of file extra_validation_lang.php */