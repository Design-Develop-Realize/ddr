<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Error 404
$lang['error_404_title'] = 'Stránka nenalezena';
$lang['error_404_message'] = 'Nepodařilo se nám najít stránku, kterou byla požadována. Prosím přejděte na <a href="%s">domovskou stránku</a>.';

// Database
$lang['error_invalid_db_group'] = 'Databáze se pokouší použít neplatnou skupinu konfiguračních údajů "%s".';

/* End of file errors_lang.php */